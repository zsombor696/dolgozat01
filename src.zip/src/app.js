/*
* File: app.js
* Author: Juhász Zsombor
* Copyright: 2024, Juhász Zsombor
* Group: Szoft. Fejl. 1-2-N
* Date: 2024-04-03
* Github: https://github.com/zsombor696/
* Licenc: GNU GPL
*/
calcButton.addEventListener('click', () => {
    console.log('működik')
    startCalc()
})
const sideLengthInput = documet.querySelector('#sideLength')
const volumeInput = document.querySelector('#volume')
const calcButton = document.querySelector('#calcButton')

function startCalc() {
    const sideLength = Number(sideLengthInput.value)
    const calcVolume = calcVolume(sideLength)
    volumeInput.value = volume
}
 
function calcVolume() {
    4 * sideLength * Math.sqrt(2 + Math.sqrt(2));
    return volume;
}